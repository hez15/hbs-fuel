local notificationsEnabled = Config.NotificationsEnabled ~= false
local hudVisible = false

function HBSFuelNotify(message, notifyType)
    if not notificationsEnabled or not message or message == '' then
        return
    end

    lib.notify({
        title = Config.NotifyTitle or 'Fuel',
        description = message,
        type = notifyType or 'inform'
    })
end

function HBSFuelShowHud(payload)
    if not Config.HudEnabled or not payload then return end
    hudVisible = true
    payload.action = 'showFuelHud'
    SendNUIMessage(payload)
end

function HBSFuelHideHud()
    if not hudVisible then return end
    hudVisible = false
    SendNUIMessage({ action = 'hideFuelHud' })
end

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    HBSFuelHideHud()
end)
