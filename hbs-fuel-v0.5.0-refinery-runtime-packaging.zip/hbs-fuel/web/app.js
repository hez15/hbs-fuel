const hud = document.getElementById('fuelHud');
const vehicleName = document.getElementById('vehicleName');
const vehicleFuel = document.getElementById('vehicleFuel');
const fuelTypeBadge = document.getElementById('fuelTypeBadge');
const tankLitres = document.getElementById('tankLitres');
const pricePerLitre = document.getElementById('pricePerLitre');
const stationStock = document.getElementById('stationStock');
const paymentMethod = document.getElementById('paymentMethod');
const addingLitres = document.getElementById('addingLitres');
const estimateCost = document.getElementById('estimateCost');
const fuelStatus = document.getElementById('fuelStatus');

window.addEventListener('message', (event) => {
  const data = event.data || {};
  if (data.action === 'showFuelHud') {
    hud.classList.remove('hidden');
    vehicleName.textContent = data.vehicleName || 'Vehicle';
    vehicleFuel.textContent = data.fuelText || 'Fuel: 0%';
    fuelTypeBadge.textContent = (data.fuelTypeLabel || 'REGULAR').toUpperCase();
    tankLitres.textContent = data.tankText || '0.0 / 0.0L';
    pricePerLitre.textContent = data.priceText || '$0.00/L';
    stationStock.textContent = data.stockText || '0.0L';
    paymentMethod.textContent = data.paymentText || 'Cash';
    addingLitres.textContent = data.addingText || '0.0L';
    estimateCost.textContent = data.costText || '$0.00';
    fuelStatus.textContent = data.statusText || 'Nozzle ready';
    fuelStatus.className = `fuel-status ${data.statusClass || ''}`.trim();
  } else if (data.action === 'hideFuelHud') {
    hud.classList.add('hidden');
  }
});
