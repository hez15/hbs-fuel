Config = {}

Config.Debug = true
Config.UseOxTarget = true
Config.UseJerryCan = true
Config.DefaultFuelType = 'regular'
Config.DefaultTankSize = 65.0

Config.ClassTankSizes = {
    [0] = 50.0,
    [1] = 60.0,
    [2] = 70.0,
    [3] = 65.0,
    [4] = 70.0,
    [5] = 75.0,
    [6] = 80.0,
    [7] = 85.0,
    [8] = 20.0,
    [9] = 85.0,
    [10] = 120.0,
    [11] = 100.0,
    [12] = 90.0,
    [13] = 0.0,
    [14] = 0.0,
    [15] = 450.0,
    [16] = 2200.0,
    [17] = 65.0,
    [18] = 80.0,
    [19] = 120.0,
    [20] = 150.0,
    [21] = 0.0,
}

Config.LoadFuelOnVehicleEnter = true
Config.SaveFuelEverySeconds = 30
Config.RefuelTickMs = 250
Config.RefuelProgressMsPerLitre = 450
Config.PassiveDemandInterval = 900
Config.PassiveDemandBaseLitres = 35.0
Config.AllowFuelWithoutStock = false
Config.AllowUnmappedStations = true
Config.UnmappedStationSupportedFuelTypes = { 'regular', 'diesel' }

Config.BlockVehiclePumpUseInRefineryZones = true
Config.RefineryPumpExclusionFallbackRadius = 25.0
Config.PumpExclusionZones = {
    -- { coords = vec3(x, y, z), radius = 10.0 },
}
Config.DefaultStationPriceMultiplier = 1.0
Config.DefaultStationEmergencyRefill = true


Config.Banking = {
    Mode = 'qbx', -- qbx | custom
    AllowCashPayments = true,
    AllowBankPayments = true,
    UseSocietyAccounts = false,
    SocietyTable = 'managment_funds',
    SocietyNameColumn = 'society',
    SocietyMoneyColumn = 'money',
    DefaultStationStartingFunds = 0.0,
}




Config.StationFunds = {
    EnableRevenueToStation = true,
    AllowPlayerDeposits = true,
    AllowPlayerWithdrawals = true,
    DepositMethods = { 'cash', 'bank' },
    WithdrawMethod = 'bank',
    NpcFallbackEnabled = true,
    NpcFallbackTopUpToReserve = true,
    NpcFallbackDelaySeconds = 0,
    NpcFallbackCostMultiplier = 1.35,
}

Config.StationStateMultipliers = {
    healthy = 1.00,
    low = 1.08,
    critical = 1.18,
    empty = 1.25,
}

Config.StationTemplates = {
    roadside_small = {
        supports = { 'regular', 'diesel' },
        tanks = {
            regular = { current = 5500.0, max = 7000.0, reserve = 1800.0, low = 900.0, critical = 300.0, passiveDemand = 1.00 },
            diesel  = { current = 1200.0, max = 2000.0, reserve = 500.0, low = 250.0, critical = 100.0, passiveDemand = 0.55 },
        },
        priceMultiplier = 1.00,
        demandMultiplier = 0.90,
        emergencyRefill = true,
    },
    standard_station = {
        supports = { 'regular', 'diesel' },
        tanks = {
            regular = { current = 7800.0, max = 9500.0, reserve = 2400.0, low = 1200.0, critical = 450.0, passiveDemand = 1.15 },
            diesel  = { current = 2200.0, max = 3800.0, reserve = 900.0, low = 450.0, critical = 150.0, passiveDemand = 0.70 },
        },
        priceMultiplier = 1.00,
        demandMultiplier = 1.10,
        emergencyRefill = true,
    },
    truck_stop = {
        supports = { 'regular', 'diesel' },
        tanks = {
            regular = { current = 6500.0, max = 8500.0, reserve = 2200.0, low = 1100.0, critical = 400.0, passiveDemand = 0.80 },
            diesel  = { current = 4200.0, max = 7000.0, reserve = 1800.0, low = 900.0, critical = 300.0, passiveDemand = 1.35 },
        },
        priceMultiplier = 1.03,
        demandMultiplier = 1.20,
        emergencyRefill = true,
    },
    aviation_depot = {
        supports = { 'jetfuel' },
        tanks = {
            jetfuel = { current = 15000.0, max = 25000.0, reserve = 6000.0, low = 3000.0, critical = 1200.0, passiveDemand = 0.30 },
        },
        priceMultiplier = 1.15,
        demandMultiplier = 0.45,
        emergencyRefill = true,
    },
}

Config.MaxRefuelLitresPerTick = 0.75
Config.RefuelDistance = 3.5
Config.RefuelCancelKey = 202 -- BACKSPACE
Config.PumpSearchRadius = 2.5
Config.PumpVehicleSearchRadius = 5.0
Config.PlayerVehicleRefuelRange = 5.0
Config.NozzleMaxDistance = 12.0
Config.RequirePlayerOutsideVehicleForPump = true
Config.ShutOffEngineDuringRefuel = true


Config.NotificationsEnabled = false
Config.NotifyTitle = 'Fuel'
Config.HudEnabled = true
Config.HudDefaultPaymentMethod = 'Cash'
Config.HudRefreshMs = 250
Config.PumpReadyText = 'Nozzle ready - target a vehicle to refuel or target the pump to return it'

Config.NozzlePropModel = 'prop_cs_fuel_nozle'
Config.NozzleCarryAnim = {
    dict = 'timetable@gardener@filling_can',
    clip = 'gar_ig_5_filling_can',
    flag = 49,
}
Config.NozzlePropBone = 57005
Config.NozzlePropOffset = {
    x = 0.13,
    y = 0.03,
    z = -0.02,
    rx = -85.0,
    ry = 0.0,
    rz = -20.0,
}
Config.NozzleRope = {
    enabled = true,
    type = 4,
    length = 4.8,
    minLength = 0.25,
    lengthChangeRate = 0.0,
    timeMultiplier = 1.0,
    breakable = false,
    pumpOffset = { x = 0.0, y = 0.0, z = 1.25 },
}



Config.IndustrialNozzle = {
    model = 'prop_hose_nozzle',
    bone = 57005,
    offset = {
        x = 0.13,
        y = 0.03,
        z = -0.02,
        rx = -85.0,
        ry = 0.0,
        rz = -20.0,
    },
    rope = {
        enabled = true,
        type = 4,
        length = 7.5,
        minLength = 0.25,
        lengthChangeRate = 0.0,
        timeMultiplier = 1.0,
        breakable = false,
        anchorOffset = { x = 0.0, y = 0.0, z = 1.15 },
    },
}


Config.Refinery = {
    AutoProcessEnabled = true,
    AutoRetrySeconds = 15,
    RuntimeSaveIntervalSeconds = 30,
    ValveStaysOpen = true,
    AllowManualStart = true,
    AllowManualStop = true,
    PackageBottleLitres = 1.0,
    PackageDrumLitres = 5.0,
}

Config.Tanker = {
    Roles = {
        crude = {
            models = { 'tanker2' },
            maxLitres = 12000.0,
            label = 'Crude Tanker',
        },
        refined = {
            models = { 'tanker' },
            maxLitres = 12000.0,
            label = 'Fuel Tanker',
        },
    },
    SupportedModels = { 'tanker', 'tanker2' },
    DefaultMaxLitres = 12000.0,
    SearchRadius = 12.0,
    HoseMaxDistance = 15.0,
    ValveOpenSeconds = 120,
    CrudeLoadStepSeconds = 10,
    RefineStepSeconds = 12,
    FuelLoadStepSeconds = 12,
    FuelUnloadStepSeconds = 12,
}

Config.VehicleFuelRules = {
    Default = { 'regular' },
    ClassBlacklist = {
        [13] = { 'regular', 'diesel', 'jetfuel' }, -- cycles
        [21] = { 'regular', 'diesel', 'jetfuel' }, -- trains
    },
    ModelBlacklist = {},
    ClassDefaults = {
        [0] = { 'regular' },  -- compacts
        [1] = { 'regular' },  -- sedans
        [2] = { 'regular' },  -- SUVs
        [3] = { 'regular' },  -- coupes
        [4] = { 'regular' },  -- muscle
        [5] = { 'regular' },  -- sports classics
        [6] = { 'regular' },  -- sports
        [7] = { 'regular' },  -- super
        [8] = { 'regular' },  -- motorcycles
        [9] = { 'regular' },  -- off-road
        [10] = { 'diesel' },  -- industrial
        [11] = { 'diesel' },  -- utility
        [12] = { 'regular' }, -- vans
        [13] = {},            -- cycles
        [14] = { 'diesel' },  -- boats
        [15] = { 'jetfuel' }, -- helicopters
        [16] = { 'jetfuel' }, -- planes
        [17] = { 'diesel' },  -- service
        [18] = { 'regular' }, -- emergency
        [19] = { 'diesel' },  -- military
        [20] = { 'diesel' },  -- commercial
        [21] = {},            -- trains
    },
    ModelOverrides = {
        -- diesel road fleet overrides
        benson = { 'diesel' },
        boxville = { 'diesel' },
        bus = { 'diesel' },
        coach = { 'diesel' },
        docktug = { 'diesel' },
        hauler = { 'diesel' },
        mule = { 'diesel' },
        packer = { 'diesel' },
        phantom = { 'diesel' },
        phantom3 = { 'diesel' },
        pounder = { 'diesel' },
        ripley = { 'diesel' },
        rumpo = { 'diesel' },
        stockade = { 'diesel' },
        tanker = { 'diesel' },
        tanker2 = { 'diesel' },
        tiptruck = { 'diesel' },
        tiptruck2 = { 'diesel' },
        trash = { 'diesel' },
        trash2 = { 'diesel' },
        vetir = { 'diesel' },

        -- aviation
        annihilator = { 'jetfuel' },
        frogger = { 'jetfuel' },
        havok = { 'jetfuel' },
        luxor = { 'jetfuel' },
        maverick = { 'jetfuel' },
        shamal = { 'jetfuel' },
        swift = { 'jetfuel' },
        volatus = { 'jetfuel' },
    }
}

Config.Features = {
    FuelUsage = true,
    JerryCan = true,
    StationStock = true,
    PassiveDemand = true,
    Refinery = true,
    TankerJobs = true,
    JetFuel = true,
    MotorOil = true,
    DynamicPricing = true,
    EmergencyAutoRefill = true,
}

Config.Usage = {
    BaseDrainMultiplier = 1.0,
    EngineOnOnly = true,
    DrainByRPM = true,
    IdleDrainPerSecond = 0.005,
    ClassMultipliers = {
        [0] = 0.90,
        [1] = 1.00,
        [2] = 1.10,
        [3] = 1.05,
        [4] = 1.25,
        [5] = 1.15,
        [6] = 1.30,
        [7] = 1.60,
        [8] = 0.55,
        [9] = 1.10,
        [10] = 1.25,
        [11] = 1.15,
        [12] = 1.05,
        [13] = 0.0,
        [14] = 0.0,
        [15] = 2.80,
        [16] = 3.50,
        [17] = 1.00,
        [18] = 1.40,
        [19] = 1.60,
        [20] = 1.20,
        [21] = 0.0,
    }
}

Config.RefineryRecipes = {
    crude_basic = {
        input = { crude = 100.0 },
        output = {
            regular = 55.0,
            diesel = 20.0,
            jetfuel = 15.0,
            motoroil = 10.0,
        },
        processTime = 300,
    }
}

Config.Items = {
    JerryCanFilled = 'jerry_can_fuel',
    JerryCanEmpty = 'jerry_can_empty',
    MotorOilBottle = 'motoroil_bottle',
    MotorOilDrum = 'motoroil_drum',
}

Config.Notifications = {
    RefuelBlockedNoStock = 'This station is out of stock for that fuel type.',
    RefuelBlockedWrongFuel = 'That fuel type is not supported here.',
    RefuelBlockedAircraft = 'Aircraft must use jet fuel.',
    RefuelBlockedNoVehicle = 'No vehicle is close enough to the pump.',
    RefuelBlockedInsideVehicle = 'Get out of the vehicle to use the pump.',
    RefuelBlockedVehicleTooFar = 'Move the vehicle closer to the pump.',
    RefuelBlockedIncompatibleVehicle = 'This vehicle cannot be fuelled here.',
    RefuelCancelled = 'Refuelling cancelled.',
    NozzleGrabbed = 'Nozzle grabbed. Target the vehicle to refuel it.',
    NozzleReturned = 'Nozzle returned.',
    NozzleTooFar = 'You moved too far away from the pump.',
    RefuelStarted = 'Refuelling started.',
    RefuelComplete = 'Refuelling complete.',
    NotEnoughMoney = 'Not enough money.',

    IndustrialHoseGrabbed = 'Hose grabbed. Move to the tanker and start transfer.',
    IndustrialHoseReturned = 'Hose returned.',
    IndustrialTooFar = 'You moved too far from the hose anchor.',
    NoTankerNearby = 'No supported tanker is nearby.',
    TankerWrongProduct = 'That tanker is carrying the wrong product.',
    TankerWrongRoleCrude = 'You need a crude tanker trailer here (tanker2).',
    TankerWrongRoleRefined = 'You need a refined fuel tanker trailer here (tanker).',
    TankerFull = 'That tanker is already full.',
    TankerLoaded = 'Tanker loaded.',
    TankerUnloaded = 'Tanker unloaded.',
    ValveOpened = 'Valve opened. Start refining while the line is primed.',
}

