# hbs-fuel v0.5.0

QBX fuel system with public pump refuelling, litres-based vehicle fuel, station stock, refinery/tanker groundwork, networked nozzle carry, and the start of the business finance layer.

## What this build includes

### Core working features
- vehicle fuel drain and persistence by plate
- public pump nozzle flow with ox_target
- public nozzle carry synced to nearby players
- car pump nozzle prop: `prop_cs_fuel_nozle`
- refinery / industrial hose prop: `prop_hose_nozzle`
- refuel progress bar
- cash or bank payment choice
- fuel HUD card
- station stock with thresholds and fallback logic
- station templates
- tanker state persistence
- refinery stock persistence
- banking adapter start
- station funds table and revenue routing
- station deposit / withdrawal backend callbacks
- NPC fallback refill now deducts from station funds

### Still scaffold / still growing
- full ownership menus
- full contracts board and lifecycle
- society purchase flow
- full crude rental workflow
- full refined logistics payout loop
- polished synced rope visuals

## Install steps

### 1. Place the resource
Put the folder in your resources directory, for example:

```
resources/[hbs]/hbs-fuel
```

### 2. Import SQL
Import:

```
sql/hbs-fuel.sql
```

This creates the current tables for:
- vehicle fuel state
- station stock
- refinery crude
- refinery product stock
- tanker state
- contracts
- station funds

### 3. Required resources
Make sure these start before `hbs-fuel`:

```
ensure ox_lib
ensure oxmysql
ensure ox_inventory
ensure ox_target
ensure qbx_core
```

### 4. Ensure hbs-fuel
Add this after the dependencies:

```
ensure hbs-fuel
```

### 5. Check banking config
In `shared/config.lua`, review `Config.Banking`:
- `Mode = 'qbx'` for QBX money
- `Mode = 'custom'` if you want to wire your own banking handlers
- society support defaults to your table name: `managment_funds`

### 6. Check station templates and stations
Review:
- `shared/stations.lua`
- `shared/config.lua` → `Config.StationTemplates`

The included stations are still only a starter set. Add your full station list before live use.

### 7. Jerry can item hookup
Hook your ox_inventory item use to:

```
hbs-fuel:client:useJerryCan
```

Suggested metadata:

```lua
metadata = {
    fuelType = 'regular',
    litres = 15.0
}
```

### 8. Tanker model rules
Current hard split:
- `tanker2` = crude only
- `tanker` = refined products only

Review in `shared/config.lua` under `Config.Tanker.Roles`.

### 9. Optional finance config
Review `Config.StationFunds` in `shared/config.lua` for:
- station revenue routing
- player deposit/withdraw toggles
- deposit payment methods
- withdraw payout method
- NPC fallback refill cost multiplier

## Current useful callbacks / exports

### Server callbacks
- `hbs-fuel:server:getStationFunds`
- `hbs-fuel:server:depositStationFunds`
- `hbs-fuel:server:withdrawStationFunds`

### Server exports
- `GetStationFunds(stationId)`
- `AddStationFunds(stationId, amount, reason)`
- `RemoveStationFunds(stationId, amount, reason)`
- `GetSocietyBalance(account)`

## Admin commands
- `/fuel_refill_station [stationId] [fuelType] [litres]`
- `/fuel_toggle_stock`

## Notes
- fuel is stored internally in litres
- vehicle UI/native fuel still maps to GTA fuel level display
- the nozzle prop is now synced as a carry prop to other players, but rope visuals are still not fully network-perfect
- station funds are now part of the backend and are ready for the later ownership layer

## Recommended next step
Continue with:
- full refinery backend cleanup
- contracts backend
- ownership backend on top of station funds


## New in v0.5.0
- refinery runtime persistence (`hbs_fuel_refinery_runtime`)
- valve open/closed state now saves across restart
- refinery processing state and batch end time now save across restart
- optional automatic refinery processing when valve is open
- manual stop batch callback
- motor oil packaging callback for bottles and drums
- refinery stock dialog now shows valve and processing status

## Install / update notes for v0.5.0
If you are updating from an older version, re-import `sql/hbs-fuel.sql` so the new table below is created:
- `hbs_fuel_refinery_runtime`

Then restart these in order:
1. `ox_lib`
2. `oxmysql`
3. `ox_inventory`
4. `ox_target`
5. `qbx_core`
6. `hbs-fuel`

### Optional refinery config
Review `shared/config.lua` → `Config.Refinery`:
- `AutoProcessEnabled`
- `AutoRetrySeconds`
- `ValveStaysOpen`
- `AllowManualStart`
- `AllowManualStop`
- `PackageBottleLitres`
- `PackageDrumLitres`

### Motor oil packaging items
Make sure these exist in your inventory setup if you want packaging to work:
- `motoroil_bottle`
- `motoroil_drum`
