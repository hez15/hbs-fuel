local activeRefuels = {}

local function getStationById(stationId)
    if stationId and StationState[stationId] then
        return StationState[stationId]
    end
    return nil
end

local function stationSupportsFuel(station, fuelType)
    for _, supported in ipairs(station.supports or {}) do
        if supported == fuelType then
            return true
        end
    end

    return false
end

local function getTankerRoleForModel(modelName)
    if not modelName then return nil end
    modelName = string.lower(modelName)
    for role, data in pairs(Config.Tanker.Roles or {}) do
        for i = 1, #(data.models or {}) do
            if modelName == string.lower(data.models[i]) then
                return role
            end
        end
    end
    return nil
end

local function calculatePricePerLitre(station, fuelType)
    local fuel = FuelTypes[fuelType]
    if not fuel then return nil end

    local price = fuel.price * (station and station.priceMultiplier or Config.DefaultStationPriceMultiplier)

    if Config.Features.DynamicPricing and station and station.tanks[fuelType] then
        local state = HBSFuel.GetTankState(station.tanks[fuelType])
        local mult = (Config.StationStateMultipliers or {})[state] or 1.0
        price = price * mult
    end

    return HBSFuel.Round(price, 2)
end


local function canUseStationFundsRevenue()
    return not Config.StationFunds or Config.StationFunds.EnableRevenueToStation ~= false
end

local function npcFallbackCostPerLitre(station, fuelType)
    local base = FuelTypes[fuelType] and FuelTypes[fuelType].price or 0.0
    local stationMult = station and station.priceMultiplier or Config.DefaultStationPriceMultiplier or 1.0
    local costMult = (Config.StationFunds and Config.StationFunds.NpcFallbackCostMultiplier) or 1.35
    return HBSFuel.Round(base * stationMult * costMult, 2)
end

local function tryNpcFallbackRefill(stationId, station, fuelType, neededLitres)
    if not stationId or not station or not fuelType then return false, 0.0, 'Invalid fallback request.' end
    if not Config.Features.EmergencyAutoRefill then return false, 0.0, 'Emergency refill disabled.' end
    if not Config.StationFunds or Config.StationFunds.NpcFallbackEnabled == false then return false, 0.0, 'NPC fallback disabled.' end
    if not station.emergencyRefill then return false, 0.0, 'This station does not allow emergency refill.' end

    local tank = station.tanks[fuelType]
    if not tank then return false, 0.0, 'Tank not found.' end

    local targetLitres = tonumber(neededLitres) or 0.0
    if Config.StationFunds.NpcFallbackTopUpToReserve ~= false then
        local reserve = tonumber(tank.reserve) or 0.0
        if reserve > targetLitres then
            targetLitres = reserve
        end
    end

    local free = math.max((tonumber(tank.max) or 0.0) - (tonumber(tank.current) or 0.0), 0.0)
    local moved = math.min(targetLitres, free)
    if moved <= 0.0 then
        return false, 0.0, 'Tank is already full.'
    end

    local totalCost = HBSFuel.Round(moved * npcFallbackCostPerLitre(station, fuelType), 2)
    if totalCost > 0.0 and not HBSFuelRemoveStationFunds(stationId, totalCost, ('npc_fallback_%s'):format(fuelType)) then
        return false, 0.0, 'Station does not have enough funds for NPC fallback.'
    end

    tank.current = math.min((tonumber(tank.current) or 0.0) + moved, tonumber(tank.max) or moved)
    SaveStationState(stationId)
    return true, moved, nil
end

local function getOrBuildVirtualStation(stationId)
    if stationId then
        return getStationById(stationId)
    end

    if not Config.AllowUnmappedStations then
        return nil
    end

    return {
        label = 'Generic Fuel Station',
        supports = Config.UnmappedStationSupportedFuelTypes or { Config.DefaultFuelType },
        priceMultiplier = Config.DefaultStationPriceMultiplier,
        emergencyRefill = Config.DefaultStationEmergencyRefill,
        tanks = {
            [Config.DefaultFuelType] = { current = 999999.0, max = 999999.0 }
        }
    }
end

lib.callback.register('hbs-fuel:server:previewRefuel', function(source, stationId, fuelType, litresNeeded, paymentMethod)
    local station = getOrBuildVirtualStation(stationId)
    if not station then
        return { ok = false, message = 'No configured station found.' }
    end

    if not FuelTypes[fuelType] then
        return { ok = false, message = 'Invalid fuel type.' }
    end

    if not stationSupportsFuel(station, fuelType) then
        return { ok = false, message = Config.Notifications.RefuelBlockedWrongFuel }
    end

    local tank = station.tanks[fuelType] or { current = 0.0, max = 0.0 }
    local available = tank.current

    if Config.Features.StationStock and available <= 0.0 then
        if stationId then
            local ok, moved = tryNpcFallbackRefill(stationId, station, fuelType, litresNeeded)
            if ok then
                available = math.max((tank.current or 0.0), moved)
            elseif Config.AllowFuelWithoutStock then
                available = litresNeeded
            else
                return { ok = false, message = Config.Notifications.RefuelBlockedNoStock }
            end
        elseif Config.AllowFuelWithoutStock then
            available = litresNeeded
        else
            return { ok = false, message = Config.Notifications.RefuelBlockedNoStock }
        end
    end

    local approved = math.min(litresNeeded or 0.0, available)
    local pricePerLitre = calculatePricePerLitre(station, fuelType)
    local totalPrice = HBSFuel.Round(approved * pricePerLitre, 2)

    paymentMethod = (paymentMethod == 'bank' and 'bank') or 'cash'

    if not HBSFuelHasMoney(source, totalPrice, paymentMethod) then
        return { ok = false, message = Config.Notifications.NotEnoughMoney }
    end

    return {
        ok = true,
        approvedLitres = approved,
        pricePerLitre = pricePerLitre,
        totalPrice = totalPrice,
        stationLabel = station.label,
        paymentMethod = paymentMethod,
    }
end)

lib.callback.register('hbs-fuel:server:commitRefuelTick', function(source, stationId, fuelType, litres, paymentMethod)
    litres = tonumber(litres) or 0.0
    if litres <= 0.0 then
        return { ok = false, message = 'Invalid litres.' }
    end

    local station = getOrBuildVirtualStation(stationId)
    if not station then
        return { ok = false, message = 'No configured station found.' }
    end

    if not FuelTypes[fuelType] then
        return { ok = false, message = 'Invalid fuel type.' }
    end

    if not stationSupportsFuel(station, fuelType) then
        return { ok = false, message = Config.Notifications.RefuelBlockedWrongFuel }
    end

    paymentMethod = (paymentMethod == 'bank' and 'bank') or 'cash'

    local approvedLitres = litres
    if Config.Features.StationStock then
        station.tanks[fuelType] = station.tanks[fuelType] or { current = 0.0, max = litres }
        local tank = station.tanks[fuelType]
        if tank.current < approvedLitres and not Config.AllowFuelWithoutStock then
            if stationId then
                local needed = approvedLitres - (tonumber(tank.current) or 0.0)
                tryNpcFallbackRefill(stationId, station, fuelType, needed)
            end

            if tank.current < approvedLitres then
                approvedLitres = math.max(tank.current, 0.0)
            end
        end
    end

    if approvedLitres <= 0.0 then
        return { ok = false, message = Config.Notifications.RefuelBlockedNoStock }
    end

    local pricePerLitre = calculatePricePerLitre(station, fuelType)
    local totalPrice = HBSFuel.Round(approvedLitres * pricePerLitre, 2)

    if not HBSFuelHasMoney(source, totalPrice, paymentMethod) then
        return { ok = false, message = Config.Notifications.NotEnoughMoney }
    end

    if Config.Features.StationStock then
        local tank = station.tanks[fuelType]
        tank.current = math.max(tank.current - approvedLitres, 0.0)
        if stationId then
            SaveStationState(stationId)
        end
    end

    if not HBSFuelRemoveMoney(source, totalPrice, paymentMethod, ('fuel_purchase_%s'):format(fuelType)) then
        return { ok = false, message = Config.Notifications.NotEnoughMoney }
    end

    if stationId and canUseStationFundsRevenue() then
        HBSFuelAddStationFunds(stationId, totalPrice, ('fuel_sale_%s'):format(fuelType))
    end

    activeRefuels[source] = {
        stationId = stationId,
        fuelType = fuelType,
        litres = (activeRefuels[source] and activeRefuels[source].litres or 0.0) + approvedLitres,
        totalPrice = (activeRefuels[source] and activeRefuels[source].totalPrice or 0.0) + totalPrice,
    }

    return {
        ok = true,
        litres = approvedLitres,
        totalPrice = totalPrice,
        pricePerLitre = pricePerLitre,
    }
end)

lib.callback.register('hbs-fuel:server:unloadTankerToStation', function(_, stationId, plate, litres, modelName)
    litres = tonumber(litres) or 0.0
    if not stationId or not plate or litres <= 0.0 then
        return { ok = false, message = 'Invalid tanker unload.' }
    end

    if getTankerRoleForModel(modelName) ~= 'refined' then
        return { ok = false, message = Config.Notifications.TankerWrongRoleRefined }
    end

    local station = getStationById(stationId)
    if not station then
        return { ok = false, message = 'Station not found.' }
    end

    local load = MySQL.single.await('SELECT fuel_type, litres, max_litres FROM hbs_fuel_tanker_state WHERE plate = ?', { plate })
    if not load or not load.fuel_type or tonumber(load.litres) <= 0.0 then
        return { ok = false, message = 'Tanker is empty.' }
    end

    local fuelType = load.fuel_type
    if fuelType == 'crude' then
        return { ok = false, message = 'Crude must be unloaded at the refinery.' }
    end

    if not stationSupportsFuel(station, fuelType) then
        return { ok = false, message = Config.Notifications.RefuelBlockedWrongFuel }
    end

    station.tanks[fuelType] = station.tanks[fuelType] or { current = 0.0, max = litres }
    local tank = station.tanks[fuelType]
    local free = math.max(tank.max - tank.current, 0.0)
    local tankerLitres = tonumber(load.litres)
    local moved = math.min(litres, tankerLitres, free)
    if moved <= 0.0 then
        return { ok = false, message = 'Station tank is already full.' }
    end

    tank.current = tank.current + moved
    SaveStationState(stationId)
    exports['hbs-fuel']:SetTankerLoad(plate, tankerLitres - moved > 0.01 and fuelType or nil, math.max(tankerLitres - moved, 0.0), tonumber(load.max_litres) or Config.Tanker.DefaultMaxLitres)

    return { ok = true, litres = moved, fuelType = fuelType, stationLevel = tank.current, message = Config.Notifications.TankerUnloaded }
end)

exports('GetStationStock', function(stationId, fuelType)
    local station = getStationById(stationId)
    return station and station.tanks[fuelType] and station.tanks[fuelType].current or nil
end)

exports('AddStationStock', function(stationId, fuelType, litres)
    local station = getStationById(stationId)
    if not station then return false end

    station.tanks[fuelType] = station.tanks[fuelType] or { current = 0.0, max = litres }
    station.tanks[fuelType].current = math.min(station.tanks[fuelType].current + litres, station.tanks[fuelType].max)
    SaveStationState(stationId)
    return true
end)

CreateThread(function()
    while true do
        Wait(Config.PassiveDemandInterval * 1000)
        if not Config.Features.PassiveDemand or not Config.Features.StationStock then
            goto continue
        end

        for stationId, station in pairs(StationState) do
            for fuelType, tank in pairs(station.tanks or {}) do
                local drain = Config.PassiveDemandBaseLitres
                    * (station.demandMultiplier or 1.0)
                    * (tank.passiveDemand or 1.0)
                tank.current = math.max((tonumber(tank.current) or 0.0) - drain, 0.0)

                if tank.current <= 0.0 and not Config.AllowFuelWithoutStock then
                    tryNpcFallbackRefill(stationId, station, fuelType, tonumber(tank.reserve) or 0.0)
                end
            end
            SaveStationState(stationId)
        end

        ::continue::
    end
end)

lib.callback.register('hbs-fuel:server:getStationFunds', function(_, stationId)
    if not stationId then return 0.0 end
    return HBSFuelGetStationFunds(stationId)
end)


lib.callback.register('hbs-fuel:server:depositStationFunds', function(source, stationId, amount, account)
    amount = HBSFuel.Round(tonumber(amount) or 0.0, 2)
    if not stationId or amount <= 0.0 then
        return { ok = false, message = 'Invalid station deposit.' }
    end
    if not (Config.StationFunds and Config.StationFunds.AllowPlayerDeposits ~= false) then
        return { ok = false, message = 'Station deposits are disabled.' }
    end

    local allowedMethods = Config.StationFunds.DepositMethods or { 'cash', 'bank' }
    local selected = (account == 'bank' and 'bank') or 'cash'
    local valid = false
    for i = 1, #allowedMethods do
        if allowedMethods[i] == selected then valid = true break end
    end
    if not valid then
        return { ok = false, message = 'That payment method is not allowed for station deposits.' }
    end

    if not HBSFuelHasMoney(source, amount, selected) then
        return { ok = false, message = Config.Notifications.NotEnoughMoney }
    end
    if not HBSFuelRemoveMoney(source, amount, selected, 'station_funds_deposit') then
        return { ok = false, message = Config.Notifications.NotEnoughMoney }
    end

    HBSFuelAddStationFunds(stationId, amount, 'player_deposit')
    return { ok = true, funds = HBSFuelGetStationFunds(stationId), amount = amount, account = selected }
end)

lib.callback.register('hbs-fuel:server:withdrawStationFunds', function(source, stationId, amount)
    amount = HBSFuel.Round(tonumber(amount) or 0.0, 2)
    if not stationId or amount <= 0.0 then
        return { ok = false, message = 'Invalid station withdrawal.' }
    end
    if not (Config.StationFunds and Config.StationFunds.AllowPlayerWithdrawals ~= false) then
        return { ok = false, message = 'Station withdrawals are disabled.' }
    end

    local method = ((Config.StationFunds and Config.StationFunds.WithdrawMethod) == 'cash' and 'cash') or 'bank'
    if not HBSFuelRemoveStationFunds(stationId, amount, 'player_withdrawal') then
        return { ok = false, message = 'Station does not have enough funds.' }
    end
    if not HBSFuelAddMoney(source, amount, method, 'station_funds_withdrawal') then
        HBSFuelAddStationFunds(stationId, amount, 'withdrawal_refund')
        return { ok = false, message = 'Failed to pay out withdrawal.' }
    end

    return { ok = true, funds = HBSFuelGetStationFunds(stationId), amount = amount, account = method }
end)
