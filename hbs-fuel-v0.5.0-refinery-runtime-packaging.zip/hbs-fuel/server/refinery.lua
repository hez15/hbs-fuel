local function getRefinery(refineryId)
    return refineryId and RefineryState[refineryId] or nil
end

local function getRuntime(refinery)
    refinery.runtime = refinery.runtime or {
        valveOpen = false,
        isProcessing = false,
        processEndsAt = nil,
        activeRecipe = refinery.recipe,
    }
    return refinery.runtime
end

local function getTankerRoleForModel(modelName)
    if not modelName then return nil end
    modelName = string.lower(modelName)
    for role, data in pairs(Config.Tanker.Roles or {}) do
        for i = 1, #(data.models or {}) do
            if modelName == string.lower(data.models[i]) then
                return role, data
            end
        end
    end
    return nil
end

local function getTankerMaxLitresForRole(role)
    local data = role and Config.Tanker.Roles and Config.Tanker.Roles[role] or nil
    return data and tonumber(data.maxLitres) or Config.Tanker.DefaultMaxLitres
end

local function getRecipe(refinery)
    local runtime = getRuntime(refinery)
    local recipeName = runtime.activeRecipe or refinery.recipe
    return recipeName and Config.RefineryRecipes[recipeName] or nil, recipeName
end

local function canRecipeOutputFit(refinery, recipe)
    for fuelType, amount in pairs(recipe.output or {}) do
        local stock = refinery.products[fuelType] or { current = 0.0, max = 0.0 }
        local free = math.max((tonumber(stock.max) or 0.0) - (tonumber(stock.current) or 0.0), 0.0)
        if free < (tonumber(amount) or 0.0) then
            local fuel = FuelTypes[fuelType]
            return false, ('Not enough %s storage capacity.'):format(fuel and fuel.label or fuelType)
        end
    end
    return true
end

local function canStartBatch(refinery)
    local runtime = getRuntime(refinery)
    if runtime.isProcessing then
        return false, 'Batch already running.'
    end
    if not runtime.valveOpen then
        return false, 'Open the valve first.'
    end
    local recipe = getRecipe(refinery)
    if not recipe then
        return false, 'Recipe missing.'
    end
    if (tonumber(refinery.crude.current) or 0.0) < (tonumber(recipe.input.crude) or 0.0) then
        return false, 'Not enough crude.'
    end
    local fits, fitReason = canRecipeOutputFit(refinery, recipe)
    if not fits then
        return false, fitReason
    end
    return true
end

local function finishBatch(refineryId)
    local refinery = getRefinery(refineryId)
    if not refinery then return false, 'Invalid refinery.' end
    local runtime = getRuntime(refinery)
    if not runtime.isProcessing then return false, 'No batch is running.' end

    local recipe = getRecipe(refinery)
    if not recipe then
        runtime.isProcessing = false
        runtime.processEndsAt = nil
        SaveRefineryState(refineryId)
        return false, 'Recipe missing.'
    end

    for fuelType, amount in pairs(recipe.output or {}) do
        refinery.products[fuelType] = refinery.products[fuelType] or { current = 0.0, max = amount }
        refinery.products[fuelType].current = math.min((refinery.products[fuelType].current or 0.0) + amount, refinery.products[fuelType].max or amount)
    end

    runtime.isProcessing = false
    runtime.processEndsAt = nil
    SaveRefineryState(refineryId)
    return true
end

local function startBatch(refineryId, manual)
    local refinery = getRefinery(refineryId)
    if not refinery then return false, 'Invalid refinery.' end
    if manual and Config.Refinery and Config.Refinery.AllowManualStart == false then
        return false, 'Manual start is disabled.'
    end

    local ok, reason = canStartBatch(refinery)
    if not ok then return false, reason end

    local recipe = getRecipe(refinery)
    local runtime = getRuntime(refinery)
    refinery.crude.current = math.max((tonumber(refinery.crude.current) or 0.0) - (tonumber(recipe.input.crude) or 0.0), 0.0)
    runtime.isProcessing = true
    runtime.processEndsAt = os.time() + math.max(tonumber(recipe.processTime) or 1, 1)
    SaveRefineryState(refineryId)
    return true
end

exports('AddCrudeToRefinery', function(refineryId, litres)
    local refinery = getRefinery(refineryId)
    if not refinery then return false end
    refinery.crude.current = math.min((tonumber(refinery.crude.current) or 0.0) + (tonumber(litres) or 0.0), refinery.crude.max)
    SaveRefineryState(refineryId)
    return true
end)

exports('ProcessRefineryBatch', function(refineryId)
    return startBatch(refineryId, true)
end)

exports('GetRefineryState', function(refineryId)
    return getRefinery(refineryId)
end)

exports('SetRefineryValve', function(refineryId, state)
    local refinery = getRefinery(refineryId)
    if not refinery then return false end
    local runtime = getRuntime(refinery)
    runtime.valveOpen = state == true
    SaveRefineryState(refineryId)
    return true
end)

lib.callback.register('hbs-fuel:server:getRefineryData', function(_, refineryId)
    local refinery = getRefinery(refineryId)
    if not refinery then return nil end
    local runtime = getRuntime(refinery)
    return {
        label = refinery.label,
        crude = refinery.crude,
        products = refinery.products,
        recipe = refinery.recipe,
        runtime = {
            valveOpen = runtime.valveOpen,
            isProcessing = runtime.isProcessing,
            processEndsAt = runtime.processEndsAt,
            activeRecipe = runtime.activeRecipe,
            secondsRemaining = runtime.processEndsAt and math.max(runtime.processEndsAt - os.time(), 0) or 0,
        }
    }
end)

lib.callback.register('hbs-fuel:server:openRefineryValve', function(_, refineryId)
    local refinery = getRefinery(refineryId)
    if not refinery then
        return { ok = false, message = 'Refinery not found.' }
    end
    local runtime = getRuntime(refinery)
    runtime.valveOpen = not runtime.valveOpen
    SaveRefineryState(refineryId)
    return { ok = true, message = runtime.valveOpen and 'Refinery valve opened.' or 'Refinery valve closed.', valveOpen = runtime.valveOpen }
end)

lib.callback.register('hbs-fuel:server:startRefineryBatch', function(_, refineryId)
    local ok, reason = startBatch(refineryId, true)
    if not ok then
        return { ok = false, message = reason or 'Unable to start batch.' }
    end
    return { ok = true, message = 'Refinery batch started.' }
end)

lib.callback.register('hbs-fuel:server:stopRefineryBatch', function(_, refineryId)
    if Config.Refinery and Config.Refinery.AllowManualStop == false then
        return { ok = false, message = 'Manual stop is disabled.' }
    end
    local refinery = getRefinery(refineryId)
    if not refinery then return { ok = false, message = 'Refinery not found.' } end
    local runtime = getRuntime(refinery)
    if not runtime.isProcessing then return { ok = false, message = 'No batch is running.' } end
    runtime.isProcessing = false
    runtime.processEndsAt = nil
    SaveRefineryState(refineryId)
    return { ok = true, message = 'Refinery batch stopped.' }
end)

lib.callback.register('hbs-fuel:server:packageMotorOil', function(source, refineryId, packageType, count)
    if not Config.Features.MotorOil then
        return { ok = false, message = 'Motor oil is disabled.' }
    end

    local refinery = getRefinery(refineryId)
    if not refinery then return { ok = false, message = 'Refinery not found.' } end
    local product = refinery.products.motoroil or { current = 0.0, max = 0.0 }

    count = math.max(math.floor(tonumber(count) or 0), 0)
    if count <= 0 then return { ok = false, message = 'Invalid amount.' } end

    local itemName, litresPerItem
    if packageType == 'drum' then
        itemName = Config.Items.MotorOilDrum
        litresPerItem = (Config.Refinery and Config.Refinery.PackageDrumLitres) or 5.0
    else
        itemName = Config.Items.MotorOilBottle
        litresPerItem = (Config.Refinery and Config.Refinery.PackageBottleLitres) or 1.0
        packageType = 'bottle'
    end

    local needed = litresPerItem * count
    if (tonumber(product.current) or 0.0) < needed then
        return { ok = false, message = 'Not enough motor oil in refinery stock.' }
    end

    local player = exports.qbx_core:GetPlayer(source)
    if not player then return { ok = false, message = 'Player not found.' } end

    local added = exports.ox_inventory:AddItem(source, itemName, count, { litres = litresPerItem, product = 'motoroil', packaged = packageType })
    if not added then
        return { ok = false, message = 'Inventory full or item missing.' }
    end

    product.current = math.max((tonumber(product.current) or 0.0) - needed, 0.0)
    SaveRefineryState(refineryId)
    return { ok = true, message = ('Packaged %sx %s.'):format(count, packageType), litresUsed = needed }
end)

lib.callback.register('hbs-fuel:server:loadCrudeTanker', function(_, plate, litres, modelName)
    litres = tonumber(litres) or 0.0
    if not plate or litres <= 0.0 then
        return { ok = false, message = 'Invalid tanker load.' }
    end

    local role = getTankerRoleForModel(modelName)
    if role ~= 'crude' then
        return { ok = false, message = Config.Notifications.TankerWrongRoleCrude }
    end

    local current = MySQL.single.await('SELECT fuel_type, litres, max_litres FROM hbs_fuel_tanker_state WHERE plate = ?', { plate })
    local maxLitres = current and tonumber(current.max_litres) or getTankerMaxLitresForRole(role)
    local currentFuelType = current and current.fuel_type or nil
    local currentLitres = current and tonumber(current.litres) or 0.0

    if currentFuelType and currentFuelType ~= 'crude' and currentLitres > 0.0 then
        return { ok = false, message = 'Tanker already contains another product.' }
    end

    local free = math.max(maxLitres - currentLitres, 0.0)
    local moved = math.min(litres, free)
    if moved <= 0.0 then
        return { ok = false, message = Config.Notifications.TankerFull }
    end

    local finalLitres = currentLitres + moved
    exports['hbs-fuel']:SetTankerLoad(plate, 'crude', finalLitres, maxLitres)

    return { ok = true, litres = moved, tankerLitres = finalLitres, maxLitres = maxLitres, message = Config.Notifications.TankerLoaded }
end)

lib.callback.register('hbs-fuel:server:unloadCrudeToRefinery', function(_, refineryId, plate, litres)
    litres = tonumber(litres) or 0.0
    local refinery = getRefinery(refineryId)
    if not refinery or not plate or litres <= 0.0 then
        return { ok = false, message = 'Invalid crude unload.' }
    end

    local load = MySQL.single.await('SELECT fuel_type, litres, max_litres FROM hbs_fuel_tanker_state WHERE plate = ?', { plate })
    if not load or load.fuel_type ~= 'crude' or tonumber(load.litres) <= 0.0 then
        return { ok = false, message = Config.Notifications.TankerWrongProduct }
    end

    local tankerLitres = tonumber(load.litres)
    local free = math.max(refinery.crude.max - refinery.crude.current, 0.0)
    local moved = math.min(litres, tankerLitres, free)
    if moved <= 0.0 then
        return { ok = false, message = 'No refinery capacity left for crude.' }
    end

    refinery.crude.current = refinery.crude.current + moved
    SaveRefineryState(refineryId)
    exports['hbs-fuel']:SetTankerLoad(plate, tankerLitres - moved > 0.01 and 'crude' or nil, math.max(tankerLitres - moved, 0.0), tonumber(load.max_litres) or Config.Tanker.DefaultMaxLitres)

    return { ok = true, litres = moved, refineryCrude = refinery.crude.current, message = Config.Notifications.TankerUnloaded }
end)

lib.callback.register('hbs-fuel:server:loadRefinedProduct', function(_, refineryId, plate, fuelType, litres, modelName)
    litres = tonumber(litres) or 0.0
    local refinery = getRefinery(refineryId)
    if not refinery or not plate or litres <= 0.0 then
        return { ok = false, message = 'Invalid fuel load.' }
    end

    local role = getTankerRoleForModel(modelName)
    if role ~= 'refined' then
        return { ok = false, message = Config.Notifications.TankerWrongRoleRefined }
    end

    if fuelType == 'motoroil' or fuelType == 'crude' then
        return { ok = false, message = 'That product is not loaded into a road tanker here.' }
    end

    local product = refinery.products[fuelType]
    if not product or product.current <= 0.0 then
        return { ok = false, message = 'No product available.' }
    end

    local current = MySQL.single.await('SELECT fuel_type, litres, max_litres FROM hbs_fuel_tanker_state WHERE plate = ?', { plate })
    local maxLitres = current and tonumber(current.max_litres) or getTankerMaxLitresForRole(role)
    local currentFuelType = current and current.fuel_type or nil
    local currentLitres = current and tonumber(current.litres) or 0.0

    if currentFuelType and currentFuelType ~= fuelType and currentLitres > 0.0 then
        return { ok = false, message = 'Tanker already contains another product.' }
    end

    local free = math.max(maxLitres - currentLitres, 0.0)
    local moved = math.min(litres, free, product.current)
    if moved <= 0.0 then
        return { ok = false, message = 'No tanker capacity available.' }
    end

    product.current = product.current - moved
    SaveRefineryState(refineryId)
    exports['hbs-fuel']:SetTankerLoad(plate, fuelType, currentLitres + moved, maxLitres)

    return { ok = true, litres = moved, fuelType = fuelType, tankerLitres = currentLitres + moved, message = Config.Notifications.TankerLoaded }
end)

CreateThread(function()
    while true do
        Wait(2000)
        if not Config.Features.Refinery then
            goto continue
        end

        local now = os.time()
        for refineryId, refinery in pairs(RefineryState or {}) do
            local runtime = getRuntime(refinery)
            if runtime.isProcessing and runtime.processEndsAt and now >= runtime.processEndsAt then
                finishBatch(refineryId)
            elseif not runtime.isProcessing and runtime.valveOpen and Config.Refinery and Config.Refinery.AutoProcessEnabled then
                startBatch(refineryId, false)
            end
        end

        ::continue::
    end
end)
