local started = false

local function copyStationDefaults(stationId, station)
    local resolved = HBSFuel.BuildStationFromTemplate(station)
    local tanks = {}
    for fuelType, data in pairs(resolved.tanks or {}) do
        tanks[fuelType] = {
            current = tonumber(data.current) or 0.0,
            max = tonumber(data.max) or 0.0,
            reserve = tonumber(data.reserve) or 0.0,
            low = tonumber(data.low) or 0.0,
            critical = tonumber(data.critical) or 0.0,
            passiveDemand = tonumber(data.passiveDemand) or 1.0,
        }
    end

    return {
        stationId = stationId,
        label = resolved.label,
        coords = resolved.coords,
        radius = resolved.radius,
        supports = resolved.supports,
        unloadPoints = resolved.unloadPoints or {},
        priceMultiplier = resolved.priceMultiplier or 1.0,
        demandMultiplier = resolved.demandMultiplier or 1.0,
        emergencyRefill = resolved.emergencyRefill == true,
        tanks = tanks,
    }
end

StationState = StationState or {}
RefineryState = RefineryState or {}
TankerState = TankerState or {}

local function ensureTables()
    MySQL.query.await([[CREATE TABLE IF NOT EXISTS hbs_fuel_vehicle_state (
        plate VARCHAR(16) PRIMARY KEY,
        litres DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )]])

    MySQL.query.await([[CREATE TABLE IF NOT EXISTS hbs_fuel_station_stock (
        station_id VARCHAR(64) NOT NULL,
        fuel_type VARCHAR(32) NOT NULL,
        current_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        max_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        reserve_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        low_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        critical_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        passive_demand_multiplier DECIMAL(10,2) NOT NULL DEFAULT 1.00,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (station_id, fuel_type)
    )]])

    MySQL.query.await([[ALTER TABLE hbs_fuel_station_stock ADD COLUMN IF NOT EXISTS reserve_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00]])
    MySQL.query.await([[ALTER TABLE hbs_fuel_station_stock ADD COLUMN IF NOT EXISTS low_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00]])
    MySQL.query.await([[ALTER TABLE hbs_fuel_station_stock ADD COLUMN IF NOT EXISTS critical_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00]])
    MySQL.query.await([[ALTER TABLE hbs_fuel_station_stock ADD COLUMN IF NOT EXISTS passive_demand_multiplier DECIMAL(10,2) NOT NULL DEFAULT 1.00]])

    MySQL.query.await([[CREATE TABLE IF NOT EXISTS hbs_fuel_refinery_stock (
        refinery_id VARCHAR(64) NOT NULL,
        fuel_type VARCHAR(32) NOT NULL,
        current_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        max_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (refinery_id, fuel_type)
    )]])

    MySQL.query.await([[CREATE TABLE IF NOT EXISTS hbs_fuel_refinery_crude (
        refinery_id VARCHAR(64) PRIMARY KEY,
        current_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        max_litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )]])

    MySQL.query.await([[CREATE TABLE IF NOT EXISTS hbs_fuel_tanker_state (
        plate VARCHAR(16) PRIMARY KEY,
        fuel_type VARCHAR(32) NULL,
        litres DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        max_litres DECIMAL(12,2) NOT NULL DEFAULT 12000.00,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )]])

    MySQL.query.await([[CREATE TABLE IF NOT EXISTS hbs_fuel_refinery_runtime (
        refinery_id VARCHAR(64) PRIMARY KEY,
        valve_open TINYINT(1) NOT NULL DEFAULT 0,
        is_processing TINYINT(1) NOT NULL DEFAULT 0,
        process_ends_at BIGINT NULL,
        active_recipe VARCHAR(64) NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )]])

    MySQL.query.await([[CREATE TABLE IF NOT EXISTS hbs_fuel_station_funds (
        station_id VARCHAR(64) PRIMARY KEY,
        funds DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )]])
end

local function loadStationState()
    for stationId, station in pairs(Stations) do
        StationState[stationId] = copyStationDefaults(stationId, station)
        if HBSFuelBanking and HBSFuelBanking.EnsureStationFunds then
            HBSFuelBanking.EnsureStationFunds(stationId)
        end
    end

    local rows = MySQL.query.await('SELECT station_id, fuel_type, current_litres, max_litres, reserve_litres, low_litres, critical_litres, passive_demand_multiplier FROM hbs_fuel_station_stock') or {}
    for _, row in ipairs(rows) do
        local station = StationState[row.station_id]
        if station then
            station.tanks[row.fuel_type] = station.tanks[row.fuel_type] or {}
            station.tanks[row.fuel_type].current = tonumber(row.current_litres)
            station.tanks[row.fuel_type].max = tonumber(row.max_litres)
            station.tanks[row.fuel_type].reserve = tonumber(row.reserve_litres) or station.tanks[row.fuel_type].reserve or 0.0
            station.tanks[row.fuel_type].low = tonumber(row.low_litres) or station.tanks[row.fuel_type].low or 0.0
            station.tanks[row.fuel_type].critical = tonumber(row.critical_litres) or station.tanks[row.fuel_type].critical or 0.0
            station.tanks[row.fuel_type].passiveDemand = tonumber(row.passive_demand_multiplier) or station.tanks[row.fuel_type].passiveDemand or 1.0
        end
    end
end

local function loadRefineryState()
    for refineryId, refinery in pairs(Refineries) do
        RefineryState[refineryId] = {
            label = refinery.label,
            points = refinery.points,
            crude = {
                current = refinery.crude.current,
                max = refinery.crude.max,
            },
            products = {},
            recipe = refinery.recipe,
            runtime = {
                valveOpen = false,
                isProcessing = false,
                processEndsAt = nil,
                activeRecipe = refinery.recipe,
            },
        }

        for fuelType, data in pairs(refinery.products or {}) do
            RefineryState[refineryId].products[fuelType] = {
                current = data.current,
                max = data.max,
            }
        end
    end

    local crudeRows = MySQL.query.await('SELECT refinery_id, current_litres, max_litres FROM hbs_fuel_refinery_crude') or {}
    for _, row in ipairs(crudeRows) do
        if RefineryState[row.refinery_id] then
            RefineryState[row.refinery_id].crude.current = tonumber(row.current_litres)
            RefineryState[row.refinery_id].crude.max = tonumber(row.max_litres)
        end
    end

    local productRows = MySQL.query.await('SELECT refinery_id, fuel_type, current_litres, max_litres FROM hbs_fuel_refinery_stock') or {}
    for _, row in ipairs(productRows) do
        if RefineryState[row.refinery_id] then
            RefineryState[row.refinery_id].products[row.fuel_type] = RefineryState[row.refinery_id].products[row.fuel_type] or {}
            RefineryState[row.refinery_id].products[row.fuel_type].current = tonumber(row.current_litres)
            RefineryState[row.refinery_id].products[row.fuel_type].max = tonumber(row.max_litres)
        end
    end

    local runtimeRows = MySQL.query.await('SELECT refinery_id, valve_open, is_processing, process_ends_at, active_recipe FROM hbs_fuel_refinery_runtime') or {}
    for _, row in ipairs(runtimeRows) do
        local refinery = RefineryState[row.refinery_id]
        if refinery then
            refinery.runtime = refinery.runtime or {}
            refinery.runtime.valveOpen = tonumber(row.valve_open) == 1
            refinery.runtime.isProcessing = tonumber(row.is_processing) == 1
            refinery.runtime.processEndsAt = row.process_ends_at and tonumber(row.process_ends_at) or nil
            refinery.runtime.activeRecipe = row.active_recipe or refinery.recipe
        end
    end
end

function SaveStationState(stationId)
    local station = StationState[stationId]
    if not station then return end

    for fuelType, tank in pairs(station.tanks) do
        MySQL.prepare.await([[INSERT INTO hbs_fuel_station_stock (station_id, fuel_type, current_litres, max_litres, reserve_litres, low_litres, critical_litres, passive_demand_multiplier)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                current_litres = VALUES(current_litres),
                max_litres = VALUES(max_litres),
                reserve_litres = VALUES(reserve_litres),
                low_litres = VALUES(low_litres),
                critical_litres = VALUES(critical_litres),
                passive_demand_multiplier = VALUES(passive_demand_multiplier)]], {
            stationId, fuelType, tank.current, tank.max, tank.reserve or 0.0, tank.low or 0.0, tank.critical or 0.0, tank.passiveDemand or 1.0
        })
    end
end

function SaveAllStationState()
    for stationId in pairs(StationState) do
        SaveStationState(stationId)
    end
end

function SaveRefineryState(refineryId)
    local refinery = RefineryState[refineryId]
    if not refinery then return end

    MySQL.prepare.await([[INSERT INTO hbs_fuel_refinery_crude (refinery_id, current_litres, max_litres)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE current_litres = VALUES(current_litres), max_litres = VALUES(max_litres)]], {
        refineryId, refinery.crude.current, refinery.crude.max
    })

    for fuelType, stock in pairs(refinery.products or {}) do
        MySQL.prepare.await([[INSERT INTO hbs_fuel_refinery_stock (refinery_id, fuel_type, current_litres, max_litres)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE current_litres = VALUES(current_litres), max_litres = VALUES(max_litres)]], {
            refineryId, fuelType, stock.current, stock.max
        })
    end

    local runtime = refinery.runtime or {}
    MySQL.prepare.await([[INSERT INTO hbs_fuel_refinery_runtime (refinery_id, valve_open, is_processing, process_ends_at, active_recipe)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE valve_open = VALUES(valve_open), is_processing = VALUES(is_processing), process_ends_at = VALUES(process_ends_at), active_recipe = VALUES(active_recipe)]], {
        refineryId,
        runtime.valveOpen and 1 or 0,
        runtime.isProcessing and 1 or 0,
        runtime.processEndsAt,
        runtime.activeRecipe or refinery.recipe,
    })
end

CreateThread(function()
    ensureTables()
    loadStationState()
    loadRefineryState()
    started = true

    while true do
        Wait(60000)
        if started then
            SaveAllStationState()
            for refineryId in pairs(RefineryState) do
                SaveRefineryState(refineryId)
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if started then
        SaveAllStationState()
        for refineryId in pairs(RefineryState) do
            SaveRefineryState(refineryId)
        end
    end
end)
