function HBSFuelHasMoney(source, amount, account)
    return HBSFuelBanking and HBSFuelBanking.HasPlayerMoney(source, amount, account) or false
end

function HBSFuelRemoveMoney(source, amount, account, reason)
    return HBSFuelBanking and HBSFuelBanking.RemovePlayerMoney(source, amount, account, reason) or false
end

function HBSFuelAddMoney(source, amount, account, reason)
    return HBSFuelBanking and HBSFuelBanking.AddPlayerMoney(source, amount, account, reason) or false
end

function HBSFuelGetSocietyBalance(account)
    return HBSFuelBanking and HBSFuelBanking.GetSocietyBalance(account) or 0.0
end

function HBSFuelRemoveSocietyMoney(account, amount, reason)
    return HBSFuelBanking and HBSFuelBanking.RemoveSocietyMoney(account, amount, reason) or false
end

function HBSFuelAddSocietyMoney(account, amount, reason)
    return HBSFuelBanking and HBSFuelBanking.AddSocietyMoney(account, amount, reason) or false
end

function HBSFuelGetStationFunds(stationId)
    return HBSFuelBanking and HBSFuelBanking.GetStationFunds(stationId) or 0.0
end

function HBSFuelRemoveStationFunds(stationId, amount, reason)
    return HBSFuelBanking and HBSFuelBanking.RemoveStationFunds(stationId, amount, reason) or false
end

function HBSFuelAddStationFunds(stationId, amount, reason)
    return HBSFuelBanking and HBSFuelBanking.AddStationFunds(stationId, amount, reason) or false
end


exports('GetStationFunds', function(stationId)
    return HBSFuelGetStationFunds(stationId)
end)

exports('AddStationFunds', function(stationId, amount, reason)
    return HBSFuelAddStationFunds(stationId, amount, reason)
end)

exports('RemoveStationFunds', function(stationId, amount, reason)
    return HBSFuelRemoveStationFunds(stationId, amount, reason)
end)

exports('GetSocietyBalance', function(account)
    return HBSFuelGetSocietyBalance(account)
end)
