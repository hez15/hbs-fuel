local nozzleSyncState = {}

CreateThread(function()
    Wait(1000)
    print('[hbs-fuel] starter resource loaded')
end)

RegisterNetEvent('hbs-fuel:server:setNozzleSync', function(enabled)
    local src = source
    enabled = enabled == true
    nozzleSyncState[src] = enabled or nil
    TriggerClientEvent('hbs-fuel:client:nozzleSync', -1, src, enabled)
end)

AddEventHandler('playerDropped', function()
    local src = source
    if nozzleSyncState[src] then
        nozzleSyncState[src] = nil
        TriggerClientEvent('hbs-fuel:client:nozzleSync', -1, src, false)
    end
end)
