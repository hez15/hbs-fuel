local resourceName = GetCurrentResourceName()

local function roundMoney(value)
    value = tonumber(value) or 0.0
    return math.floor((value * 100.0) + 0.5) / 100.0
end

local function getPlayer(source)
    local ok, player = pcall(function()
        return exports['qbx_core']:GetPlayer(source)
    end)

    if ok then return player end
    return nil
end

local function getAccountBalance(player, account)
    if not player then return 0 end
    return tonumber(player.PlayerData and player.PlayerData.money and player.PlayerData.money[account]) or 0.0
end

local function getBankingMode()
    return (Config.Banking and Config.Banking.Mode) or 'qbx'
end

local function callCustom(fnName, ...)
    local fn = HBSFuelBanking and HBSFuelBanking.Custom and HBSFuelBanking.Custom[fnName]
    if type(fn) ~= 'function' then
        return nil, ('Missing custom banking handler: %s'):format(fnName)
    end
    return fn(...)
end

local function ensureStationFundsRow(stationId)
    if not stationId then return false end
    local starting = roundMoney(Config.Banking and Config.Banking.DefaultStationStartingFunds or 0.0)
    MySQL.prepare.await([[INSERT INTO hbs_fuel_station_funds (station_id, funds)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE station_id = VALUES(station_id)]], {
        stationId, starting
    })
    return true
end

local function getSocietyTableConfig()
    local banking = Config.Banking or {}
    return banking.SocietyTable or 'managment_funds', banking.SocietyNameColumn or 'society', banking.SocietyMoneyColumn or 'money'
end

HBSFuelBanking = HBSFuelBanking or {}
HBSFuelBanking.Custom = HBSFuelBanking.Custom or {}

function HBSFuelBanking.GetMode()
    return getBankingMode()
end

function HBSFuelBanking.GetPlayer(source)
    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('GetPlayer', source))
        if result ~= nil then return result end
    end

    return getPlayer(source)
end

function HBSFuelBanking.GetPlayerCash(source)
    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('GetPlayerCash', source))
        if result ~= nil then return tonumber(result) or 0.0 end
    end

    return getAccountBalance(getPlayer(source), 'cash')
end

function HBSFuelBanking.GetPlayerBank(source)
    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('GetPlayerBank', source))
        if result ~= nil then return tonumber(result) or 0.0 end
    end

    return getAccountBalance(getPlayer(source), 'bank')
end

function HBSFuelBanking.HasPlayerMoney(source, amount, account)
    local selected = (account == 'bank' and 'bank') or 'cash'
    amount = roundMoney(amount)

    if selected == 'cash' and Config.Banking and Config.Banking.AllowCashPayments == false then
        return false
    end

    if selected == 'bank' and Config.Banking and Config.Banking.AllowBankPayments == false then
        return false
    end

    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('HasPlayerMoney', source, amount, selected))
        if result ~= nil then return result == true end
    end

    local player = getPlayer(source)
    if not player then return false end
    return getAccountBalance(player, selected) >= amount
end

function HBSFuelBanking.RemovePlayerMoney(source, amount, account, reason)
    local selected = (account == 'bank' and 'bank') or 'cash'
    amount = roundMoney(amount)

    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('RemovePlayerMoney', source, amount, selected, reason))
        if result ~= nil then return result == true end
    end

    local player = getPlayer(source)
    if not player then return false end
    return player.Functions.RemoveMoney(selected, amount, reason or resourceName)
end

function HBSFuelBanking.AddPlayerMoney(source, amount, account, reason)
    local selected = (account == 'bank' and 'bank') or 'cash'
    amount = roundMoney(amount)

    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('AddPlayerMoney', source, amount, selected, reason))
        if result ~= nil then return result == true end
    end

    local player = getPlayer(source)
    if not player then return false end
    return player.Functions.AddMoney(selected, amount, reason or resourceName)
end

function HBSFuelBanking.GetSocietyBalance(account)
    if not account or Config.Banking.UseSocietyAccounts ~= true then return 0.0 end

    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('GetSocietyBalance', account))
        if result ~= nil then return tonumber(result) or 0.0 end
    end

    local tableName, nameColumn, moneyColumn = getSocietyTableConfig()
    local query = ('SELECT `%s` as money FROM `%s` WHERE `%s` = ? LIMIT 1'):format(moneyColumn, tableName, nameColumn)
    local row = MySQL.single.await(query, { account })
    return row and (tonumber(row.money) or 0.0) or 0.0
end

function HBSFuelBanking.RemoveSocietyMoney(account, amount, reason)
    if not account or Config.Banking.UseSocietyAccounts ~= true then return false end
    amount = roundMoney(amount)

    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('RemoveSocietyMoney', account, amount, reason))
        if result ~= nil then return result == true end
    end

    local balance = HBSFuelBanking.GetSocietyBalance(account)
    if balance < amount then return false end

    local tableName, nameColumn, moneyColumn = getSocietyTableConfig()
    local query = ('UPDATE `%s` SET `%s` = `%s` - ? WHERE `%s` = ?'):format(tableName, moneyColumn, moneyColumn, nameColumn)
    MySQL.update.await(query, { amount, account })
    return true
end

function HBSFuelBanking.AddSocietyMoney(account, amount, reason)
    if not account or Config.Banking.UseSocietyAccounts ~= true then return false end
    amount = roundMoney(amount)

    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('AddSocietyMoney', account, amount, reason))
        if result ~= nil then return result == true end
    end

    local tableName, nameColumn, moneyColumn = getSocietyTableConfig()
    local query = ('INSERT INTO `%s` (`%s`, `%s`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `%s` = `%s` + VALUES(`%s`)'):format(tableName, nameColumn, moneyColumn, moneyColumn, moneyColumn, moneyColumn)
    MySQL.prepare.await(query, { account, amount })
    return true
end

function HBSFuelBanking.EnsureStationFunds(stationId)
    return ensureStationFundsRow(stationId)
end

function HBSFuelBanking.GetStationFunds(stationId)
    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('GetStationFunds', stationId))
        if result ~= nil then return tonumber(result) or 0.0 end
    end

    ensureStationFundsRow(stationId)
    local row = MySQL.single.await('SELECT funds FROM hbs_fuel_station_funds WHERE station_id = ? LIMIT 1', { stationId })
    return row and (tonumber(row.funds) or 0.0) or 0.0
end

function HBSFuelBanking.RemoveStationFunds(stationId, amount, reason)
    amount = roundMoney(amount)

    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('RemoveStationFunds', stationId, amount, reason))
        if result ~= nil then return result == true end
    end

    ensureStationFundsRow(stationId)
    local current = HBSFuelBanking.GetStationFunds(stationId)
    if current < amount then return false end
    MySQL.update.await('UPDATE hbs_fuel_station_funds SET funds = funds - ? WHERE station_id = ?', { amount, stationId })
    return true
end

function HBSFuelBanking.AddStationFunds(stationId, amount, reason)
    amount = roundMoney(amount)

    if getBankingMode() == 'custom' then
        local result = select(1, callCustom('AddStationFunds', stationId, amount, reason))
        if result ~= nil then return result == true end
    end

    ensureStationFundsRow(stationId)
    MySQL.update.await('UPDATE hbs_fuel_station_funds SET funds = funds + ? WHERE station_id = ?', { amount, stationId })
    return true
end
